# 🧬 BioVerse — Karnataka PU Biology Learning Platform

A full-stack EdTech platform for Karnataka PU (1st & 2nd year), KCET, and NEET Biology preparation. Built with React + Vite, backed by Supabase (Postgres, Auth, Storage), with Razorpay payments and an AI Biology Tutor.

## ✨ Features

- **Student portal**: syllabus viewer, video lectures, notes, MCQ question bank, timed tests, progress tracking, KCET/NEET readiness analyzers
- **Gamification**: XP levels, streaks, leaderboards, weekly challenges, badges, flashcards, memory game, rewards store
- **Community**: discussion forum with AI-assisted replies, live classes
- **AI Biology Tutor**: chat-based tutor, AI notes generator, AI question/test generator (Karnataka PU syllabus-locked)
- **Admin CMS**: full content management (units/chapters/videos/notes/questions/tests), student management, subscriptions, analytics, notifications, bulk import, audit log
- **Auth & payments**: Supabase Auth (email/password), Razorpay checkout for Premium plans

## 🏗️ Tech Stack

| Layer | Technology |
|---|---|
| Frontend | React 18 + Vite |
| Backend | Supabase (PostgreSQL + Auth + Storage) |
| Payments | Razorpay |
| Hosting | Vercel (recommended) |
| AI | Anthropic API (Claude) |

## 📦 Project Structure

```
bioverse/
├── index.html
├── package.json
├── vite.config.js
├── .env.example
├── .gitignore
└── src/
    ├── main.jsx       # React entry point
    └── App.jsx        # Entire application (all components, pages, Supabase client)
```

> **Note:** `App.jsx` is intentionally a single large file (~7,200 lines) containing every component, the Supabase data-access layer (`sb` object), and the Razorpay helper. This mirrors how it was originally built. You're welcome to split it into multiple files/folders (`components/`, `pages/`, `lib/`) — the code has clear `// ─── SECTION ───` comment dividers to make that refactor straightforward.

## 🚀 Getting Started Locally

### 1. Clone and install

```bash
git clone https://github.com/YOUR_USERNAME/bioverse.git
cd bioverse
npm install
```

### 2. Set up environment variables

Copy `.env.example` to `.env` and fill in your values (see below for where to get them).

```bash
cp .env.example .env
```

### 3. Run the dev server

```bash
npm run dev
```

Visit `http://localhost:5173`.

### 4. Build for production

```bash
npm run build
npm run preview   # preview the production build locally
```

## 🔧 Required Setup Before Going Live

This codebase was built against a specific Supabase project during development. **You must do the following before deploying for real use:**

### A. Supabase Project

The Supabase URL and anon key are currently **hardcoded inline** near the top of `src/App.jsx`:

```js
const SUPABASE_URL  = "https://nvbaykuuxjzjeafpoexi.supabase.co";
const SUPABASE_ANON = "eyJhbGci...";
```

1. Create your own Supabase project at [supabase.com](https://supabase.com).
2. Run the SQL migrations (schema, RLS policies, seed data, helper functions) — these were applied directly via the Supabase MCP tool during development and are **not included as `.sql` files in this repo**. You'll need to recreate them. The schema includes these tables: `users` (extended `auth.users`), `units`, `chapters`, `concepts`, `videos`, `notes`, `questions`, `tests`, `test_questions`, `results`, `progress`, `subscriptions`, `payments`, `notifications`, `community_posts`, `community_replies`, plus 3 storage buckets (`notes`, `profile-pictures`, `certificates`) and RLS policies restricting students to their own data while giving admins full access.
3. Replace `SUPABASE_URL` and `SUPABASE_ANON` in `App.jsx` with your own project's values (Project Settings → API), **or** better — move them to environment variables (see "Recommended Hardening" below).

### B. Anthropic API (AI Tutor)

The AI Biology Tutor calls `https://api.anthropic.com/v1/messages` **directly from the browser with no API key header set**:

```js
async function callBioAI(messages, systemPrompt) {
  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    ...
```

This worked only inside the Claude.ai artifact sandbox (which proxies and authenticates the request for you). **It will not work in a normal deployed app** — browsers can't call the Anthropic API directly (no CORS support, and you'd be exposing your API key client-side anyway).

**You must add a backend proxy.** The simplest fix with Vercel:

1. Create `api/ai-tutor.js` (a Vercel serverless function):

```js
export default async function handler(req, res) {
  const { messages, systemPrompt } = req.body;
  const r = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": process.env.ANTHROPIC_API_KEY,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: "claude-sonnet-4-6",
      max_tokens: 1000,
      system: systemPrompt,
      messages,
    }),
  });
  const data = await r.json();
  res.status(200).json(data);
}
```

2. In `App.jsx`, change `callBioAI` to call `/api/ai-tutor` instead of `api.anthropic.com` directly.
3. Set `ANTHROPIC_API_KEY` in your Vercel project's environment variables (get one from [console.anthropic.com](https://console.anthropic.com)).

### C. Razorpay

The Razorpay key is a placeholder:

```js
const Razorpay = {
  KEY_ID: "rzp_test_BioVerseKey", // Replace with real Razorpay key
  ...
```

Replace with your real test/live key from the [Razorpay Dashboard](https://dashboard.razorpay.com/). For production, payment verification should happen server-side (a webhook or serverless function verifying the payment signature) rather than trusting the client-side `onSuccess` callback alone.

## 🔐 Recommended Hardening Before Production

- **Move secrets to environment variables.** Currently `SUPABASE_URL`, `SUPABASE_ANON`, and the Razorpay key are hardcoded in `App.jsx`. Use Vite's `import.meta.env.VITE_SUPABASE_URL` pattern instead (see `.env.example`) and update the three references in `App.jsx`.
- **Add a `.sql` migrations folder** with your schema so the database can be version-controlled and reproduced (`supabase db diff` or manually export from the Supabase dashboard's SQL editor).
- **Verify Razorpay payments server-side** rather than trusting the client `handler` callback.
- **Rotate the Super Admin credentials.** The admin panel's Super Admin login currently checks a hardcoded username/password pair directly in `App.jsx` (search for `SUPER_ADMIN_CREDENTIALS`). Move this to a Supabase-backed admin account with a real password hash before going live, or at minimum change the hardcoded values and keep them out of version control.

## 📜 Environment Variables

See `.env.example`. These are scaffolded for a typical Vite + Vercel setup; wiring them into `App.jsx` (replacing the hardcoded constants) is a manual step described above.

## 📄 License

Private project — add a license here if you intend to open-source it.
